import { useRef, useCallback } from 'react';

let audioCtx: AudioContext | null = null;
function getCtx(): AudioContext {
  if (!audioCtx) audioCtx = new AudioContext();
  return audioCtx;
}

function scheduleNote(
  ctx: AudioContext,
  dest: AudioNode,
  freq: number,
  time: number,
  dur: number,
  type: OscillatorType,
  vol: number
) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.connect(g);
  g.connect(dest);
  osc.type = type;
  osc.frequency.value = freq;
  g.gain.setValueAtTime(0, time);
  g.gain.linearRampToValueAtTime(vol, time + 0.01);
  g.gain.exponentialRampToValueAtTime(0.001, time + Math.max(dur - 0.02, 0.02));
  osc.start(time);
  osc.stop(time + dur);
}

function playBackgroundMusic(ctx: AudioContext): () => void {
  const BPM = 126;
  const B = 60 / BPM; // seconds per beat

  const master = ctx.createGain();
  master.gain.setValueAtTime(0, ctx.currentTime);
  master.gain.linearRampToValueAtTime(0.13, ctx.currentTime + 1.5);
  master.connect(ctx.destination);

  // Note frequencies (C major pentatonic + some passing tones)
  const n = {
    C3: 130.81, F3: 174.61, G3: 195.99, A3: 219.99,
    C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23,
    G4: 392.00, A4: 440.00, B4: 493.88,
    C5: 523.25, D5: 587.33, E5: 659.25,
  };

  // 8-beat melody [freq, beatOffset, beatDuration]
  const melA: [number, number, number][] = [
    [n.C4, 0, 0.5], [n.E4, 0.5, 0.5],
    [n.G4, 1, 0.25], [n.A4, 1.25, 0.25], [n.G4, 1.5, 0.5],
    [n.E4, 2, 0.5], [n.G4, 2.5, 0.5],
    [n.C4, 3, 0.75], [n.D4, 3.75, 0.25],
    [n.E4, 4, 0.5], [n.G4, 4.5, 0.5],
    [n.A4, 5, 0.25], [n.C5, 5.25, 0.25], [n.A4, 5.5, 0.5],
    [n.G4, 6, 0.5], [n.E4, 6.5, 0.25], [n.D4, 6.75, 0.25],
    [n.C4, 7, 1.0],
  ];

  // 8-beat variation (bars 3-4)
  const melB: [number, number, number][] = [
    [n.G4, 0, 0.5], [n.A4, 0.5, 0.5],
    [n.C5, 1, 0.25], [n.D5, 1.25, 0.25], [n.C5, 1.5, 0.5],
    [n.A4, 2, 0.5], [n.G4, 2.5, 0.5],
    [n.E4, 3, 0.75], [n.D4, 3.75, 0.25],
    [n.E4, 4, 0.5], [n.G4, 4.5, 0.5],
    [n.A4, 5, 0.5], [n.G4, 5.5, 0.5],
    [n.E4, 6, 0.5], [n.C4, 6.5, 0.5],
    [n.D4, 7, 0.5], [n.C4, 7.5, 0.5],
  ];

  // 8-beat bass groove [freq, beatOffset, beatDuration]
  const bassLine: [number, number, number][] = [
    [n.C3, 0, 0.8], [n.C3, 1, 0.4], [n.C3, 1.5, 0.4],
    [n.F3, 2, 0.8], [n.F3, 3, 0.8],
    [n.G3, 4, 0.8], [n.G3, 5, 0.4], [n.A3, 5.5, 0.4],
    [n.F3, 6, 0.8], [n.F3, 7, 0.4], [n.C3, 7.5, 0.4],
  ];

  // Chord stabs [freqs[], beatOffset, duration]
  const chordStabs: [number[], number, number][] = [
    [[n.C4, n.E4, n.G4], 0, 0.12],
    [[n.F3, n.A3, n.C4], 2, 0.12],
    [[n.G3, n.B4, n.D5], 4, 0.12],
    [[n.F3, n.A3, n.C4], 6, 0.12],
  ];

  let stopped = false;
  let bar = 0;
  let nextStart = ctx.currentTime + 0.05;
  const LOOP_BEATS = 8;

  function scheduleBar() {
    if (stopped) return;

    const mel = bar % 4 < 2 ? melA : melB;

    for (const [freq, off, dur] of mel) {
      scheduleNote(ctx, master, freq, nextStart + off * B, dur * B * 0.88, 'sine', 0.18);
    }
    for (const [freq, off, dur] of bassLine) {
      scheduleNote(ctx, master, freq, nextStart + off * B, dur * B, 'triangle', 0.28);
    }
    for (const [freqs, off, dur] of chordStabs) {
      for (const freq of freqs) {
        scheduleNote(ctx, master, freq, nextStart + off * B, dur * B, 'sawtooth', 0.04);
      }
    }

    bar++;
    nextStart += LOOP_BEATS * B;

    const msUntilNext = Math.max(0, (nextStart - ctx.currentTime - 0.6) * 1000);
    setTimeout(scheduleBar, msUntilNext);
  }

  scheduleBar();

  return () => {
    stopped = true;
    try {
      master.gain.cancelScheduledValues(ctx.currentTime);
      master.gain.setValueAtTime(master.gain.value, ctx.currentTime);
      master.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5);
    } catch { /* ignore */ }
  };
}

function playTone(freq: number, duration: number, type: OscillatorType = 'sine', gain = 0.3) {
  try {
    const ctx = getCtx();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();
    osc.connect(gainNode);
    gainNode.connect(ctx.destination);
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gainNode.gain.setValueAtTime(gain, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch { /* ignore */ }
}

export function useSounds() {
  const musicStopRef = useRef<(() => void) | null>(null);

  const startMusic = useCallback(() => {
    try {
      const ctx = getCtx();
      ctx.resume().then(() => {
        if (musicStopRef.current) musicStopRef.current();
        musicStopRef.current = playBackgroundMusic(ctx);
      });
    } catch { /* ignore */ }
  }, []);

  const stopMusic = useCallback(() => {
    if (musicStopRef.current) {
      musicStopRef.current();
      musicStopRef.current = null;
    }
  }, []);

  const playCardSlap = useCallback(() => {
    playTone(220, 0.07, 'triangle', 0.35);
  }, []);

  const playDraw = useCallback(() => {
    playTone(380, 0.12, 'sine', 0.18);
    setTimeout(() => playTone(320, 0.08, 'sine', 0.12), 50);
  }, []);

  const playDutch = useCallback(() => {
    try {
      const ctx = getCtx();
      [523, 659, 784, 1047].forEach((freq, i) => {
        scheduleNote(ctx, ctx.destination, freq, ctx.currentTime + i * 0.13, 0.2, 'square', 0.25);
      });
    } catch { /* ignore */ }
  }, []);

  const playError = useCallback(() => {
    playTone(160, 0.1, 'sawtooth', 0.18);
  }, []);

  return { playCardSlap, playDraw, playDutch, playError, startMusic, stopMusic };
}
