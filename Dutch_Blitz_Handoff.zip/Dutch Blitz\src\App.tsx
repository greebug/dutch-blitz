import React, { useReducer } from 'react';
import { gameReducer, initialState } from './game/engine';
import { SetupScreen } from './components/SetupScreen';
import { GameBoard } from './components/GameBoard';

export default function App() {
  const [state, dispatch] = useReducer(gameReducer, undefined, initialState);

  if (state.phase === 'setup') {
    return <SetupScreen dispatch={dispatch} />;
  }

  return <GameBoard state={state} dispatch={dispatch} />;
}
